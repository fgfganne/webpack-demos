webpackJsonp([0],{

/***/ 27:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var React = __webpack_require__(2);
var ReactDOM = __webpack_require__(8);
ReactDOM.render(React.createElement(
  'h2',
  null,
  'Hello Webpack'
), document.getElementById('b'));

/***/ })

},[27]);